import React from 'react';
import { NavLink } from 'react-router-dom';
import { FiHome, FiMessageSquare, FiBookOpen, FiShield, FiFileText, FiPieChart, FiUser } from 'react-icons/fi';

const Sidebar = () => {
  const navItems = [
    { name: 'Dashboard', path: '/dashboard', icon: <FiHome size={20} /> },
    { name: 'AI Assistant', path: '/assistant', icon: <FiMessageSquare size={20} /> },
    { name: 'Learning Quiz', path: '/quiz', icon: <FiBookOpen size={20} /> },
    { name: 'Risk Analyzer', path: '/analyzer', icon: <FiShield size={20} /> },
    { name: 'Compliance Check', path: '/compliance', icon: <FiFileText size={20} /> },
    { name: 'Analytics', path: '/analytics', icon: <FiPieChart size={20} /> },
    { name: 'Profile', path: '/profile', icon: <FiUser size={20} /> },
  ];

  return (
    <div className="w-64 h-full glass-dark border-r border-slate-700/50 hidden md:flex flex-col z-20 absolute md:relative">
      <div className="p-6">
        <h1 className="text-2xl font-bold text-gradient">PrivacyShield</h1>
        <p className="text-xs text-gray-400 mt-1">AI Awareness Platform</p>
      </div>

      <nav className="flex-1 px-4 mt-6 space-y-2">
        {navItems.map((item) => (
          <NavLink
            key={item.name}
            to={item.path}
            className={({ isActive }) =>
              `flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-300 ${
                isActive 
                  ? 'bg-primary/20 text-primary shadow-lg shadow-primary/10 border border-primary/20' 
                  : 'text-gray-400 hover:text-white hover:bg-slate-800'
              }`
            }
          >
            {item.icon}
            <span className="font-medium">{item.name}</span>
          </NavLink>
        ))}
      </nav>
      

    </div>
  );
};

export default Sidebar;
