import { GoogleGenerativeAI } from '@google/generative-ai';
import { getApiSettings } from './storage';

export const getGeminiModel = () => {
  // Check localStorage first (user-configured), then fall back to env key
  const envKey = import.meta.env.VITE_GEMINI_API_KEY;
  const localKey = getApiSettings();
  
  const isValidKey = (key) => key && key.trim() !== '' && key !== 'your_gemini_api_key_here';
  
  const apiKey = isValidKey(localKey) ? localKey.trim() : (isValidKey(envKey) ? envKey.trim() : null);
  
  if (!apiKey) throw new Error("Gemini API key is missing. Please set it in Settings.");
  
  const genAI = new GoogleGenerativeAI(apiKey);
  return genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
};

export const chatWithGemini = async (prompt, history = []) => {
  try {
    const model = getGeminiModel();
    const formattedHistory = history.map(msg => ({
      role: msg.role === 'user' ? 'user' : 'model',
      parts: [{ text: msg.text }],
    }));
    
    const chat = model.startChat({
      history: formattedHistory,
      generationConfig: {
        maxOutputTokens: 500,
      },
    });

    const result = await chat.sendMessage(prompt);
    const response = await result.response;
    return response.text();
  } catch (error) {
    console.error("Gemini Chat Error:", error);
    throw error;
  }
};

export const analyzeRiskExplanation = async (text, riskScore) => {
  try {
    const model = getGeminiModel();
    const prompt = `You are a privacy expert. I have analyzed the following text and calculated a privacy risk score of ${riskScore.toFixed(2)} out of 10. Explain why this text might be risky regarding data privacy, GDPR, or general safety. Keep it concise, around 3 sentences. Text: "${text}"`;
    const result = await model.generateContent(prompt);
    return result.response.text();
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    return "Error generating explanation. Please check your API key.";
  }
};

export const analyzeCompliance = async (policyText) => {
  try {
    const model = getGeminiModel();
    const prompt = `Act as a legal and privacy expert. Analyze this privacy policy for GDPR and CCPA compliance. Provide a summary of missing areas and recommendations. Format as plain text with clear bullet points. Policy: "${policyText.substring(0, 5000)}"`;
    const result = await model.generateContent(prompt);
    return result.response.text();
  } catch (error) {
    console.error("Gemini Compliance Error:", error);
    throw error;
  }
};
