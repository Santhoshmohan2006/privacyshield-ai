// Pure JS TF-IDF and Cosine Similarity implementation

// Pre-defined privacy risk keywords with weights
const riskDictionary = {
  'ssn': 5,
  'social security': 5,
  'credit card': 5,
  'password': 5,
  'address': 4,
  'phone number': 4,
  'email': 3,
  'bank': 4,
  'passport': 5,
  'driver license': 5,
  'dob': 4,
  'date of birth': 4,
  'location': 3,
  'ip address': 3,
  'tracking': 2,
  'cookies': 2,
  'third party': 3,
  'sell data': 5,
  'share data': 4,
  'analytics': 2
};

// Tokenizer
const tokenize = (text) => {
  return text.toLowerCase().match(/\b(\w+)\b/g) || [];
};

export const analyzePrivacyRisk = (text) => {
  if (!text) return 0;
  
  const tokens = tokenize(text);
  const totalTokens = tokens.length;
  if (totalTokens === 0) return 0;

  let riskScore = 0;
  let matches = [];

  // Simple weighted matching based on TF
  for (const [keyword, weight] of Object.entries(riskDictionary)) {
    const regex = new RegExp(`\\b${keyword}\\b`, 'gi');
    const matchCount = (text.match(regex) || []).length;
    if (matchCount > 0) {
      // Term frequency
      const tf = matchCount / totalTokens;
      // Multiply by arbitrary high weight factor to get a 0-10 scale
      riskScore += tf * weight * 100;
      matches.push({ keyword, count: matchCount });
    }
  }

  // Normalize to max 10
  riskScore = Math.min(riskScore, 10);
  
  return {
    score: riskScore,
    matches,
    level: riskScore < 3 ? 'Low' : riskScore < 7 ? 'Medium' : 'High'
  };
};

export const cosineSimilarity = (vecA, vecB) => {
  let dotProduct = 0.0;
  let normA = 0.0;
  let normB = 0.0;
  for (let i = 0; i < vecA.length; i++) {
    dotProduct += vecA[i] * vecB[i];
    normA += Math.pow(vecA[i], 2);
    normB += Math.pow(vecB[i], 2);
  }
  if (normA === 0 || normB === 0) return 0;
  return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
};
