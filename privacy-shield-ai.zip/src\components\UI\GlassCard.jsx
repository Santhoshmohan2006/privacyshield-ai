import React from 'react';
import { motion } from 'framer-motion';

const GlassCard = ({ children, className = '', animate = true, delay = 0 }) => {
  const content = (
    <div className={`glass dark:glass-dark rounded-2xl p-6 transition-all duration-300 hover:shadow-primary/10 ${className}`}>
      {children}
    </div>
  );

  if (animate) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay }}
      >
        {content}
      </motion.div>
    );
  }

  return content;
};

export default GlassCard;
