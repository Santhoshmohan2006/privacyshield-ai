import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import GlassCard from '../../components/UI/GlassCard';
import Button from '../../components/UI/Button';
import quizzesData from '../../data/quizzes.json';
import { saveScore } from '../../utils/storage';
import { motion } from 'framer-motion';

const QuizActive = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [quiz, setQuiz] = useState(null);
  const [currentQ, setCurrentQ] = useState(0);
  const [selected, setSelected] = useState(null);
  const [answers, setAnswers] = useState([]);
  const [timeLeft, setTimeLeft] = useState(300); // 5 mins

  useEffect(() => {
    const q = quizzesData.find(q => q.id === id);
    if (q) setQuiz(q);
    else navigate('/quiz');
  }, [id, navigate]);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          handleSubmit();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [answers, quiz]);

  const handleNext = () => {
    if (selected === null) return;
    const newAnswers = [...answers, selected];
    setAnswers(newAnswers);
    
    if (currentQ < quiz.questions.length - 1) {
      setCurrentQ(prev => prev + 1);
      setSelected(null);
    } else {
      finishQuiz(newAnswers);
    }
  };

  const finishQuiz = (finalAnswers) => {
    let score = 0;
    finalAnswers.forEach((ans, i) => {
      if (ans === quiz.questions[i].answer) score++;
    });
    saveScore(quiz.id, score, quiz.questions.length);
    navigate(`/quiz/result/${quiz.id}`, { state: { score, total: quiz.questions.length, answers: finalAnswers } });
  };

  const handleSubmit = () => {
    const finalAnswers = [...answers, selected !== null ? selected : -1];
    finishQuiz(finalAnswers);
  };

  if (!quiz) return <div>Loading...</div>;

  const question = quiz.questions[currentQ];

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="flex justify-between items-center bg-white/10 dark:bg-slate-800/50 p-4 rounded-2xl backdrop-blur-md">
        <h2 className="text-lg font-bold text-gray-900 dark:text-white">{quiz.title}</h2>
        <div className="flex gap-4 text-sm font-medium">
          <span className="text-gray-500 dark:text-gray-400">Question {currentQ + 1}/{quiz.questions.length}</span>
          <span className={`text-gray-900 dark:text-white ${timeLeft < 60 ? 'text-red-500' : ''}`}>
            {Math.floor(timeLeft / 60)}:{(timeLeft % 60).toString().padStart(2, '0')}
          </span>
        </div>
      </div>

      <div className="w-full bg-gray-200 dark:bg-slate-700 h-2 rounded-full overflow-hidden">
        <motion.div 
          initial={{ width: 0 }}
          animate={{ width: `${((currentQ) / quiz.questions.length) * 100}%` }}
          className="bg-primary h-full"
        />
      </div>

      <GlassCard className="p-8">
        <h3 className="text-2xl font-semibold text-gray-900 dark:text-white mb-8">{question.q}</h3>
        
        <div className="space-y-4">
          {question.options.map((opt, i) => (
            <button
              key={i}
              onClick={() => setSelected(i)}
              className={`w-full text-left p-4 rounded-xl border transition-all ${
                selected === i 
                  ? 'bg-primary/20 border-primary text-primary dark:text-white shadow-md shadow-primary/10' 
                  : 'bg-white/50 dark:bg-slate-800/50 border-gray-200 dark:border-slate-700 text-gray-700 dark:text-gray-300 hover:border-primary/50'
              }`}
            >
              {opt}
            </button>
          ))}
        </div>

        <div className="mt-8 flex justify-end">
          <Button onClick={handleNext} disabled={selected === null} className="px-8">
            {currentQ < quiz.questions.length - 1 ? 'Next Question' : 'Submit Quiz'}
          </Button>
        </div>
      </GlassCard>
    </div>
  );
};

export default QuizActive;
