import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { saveUser, getApiSettings, saveApiSettings } from '../../utils/storage';
import { toast } from 'react-hot-toast';
import GlassCard from '../../components/UI/GlassCard';
import Input from '../../components/UI/Input';
import Button from '../../components/UI/Button';
import { FiShield, FiKey } from 'react-icons/fi';

const Register = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [apiKey, setApiKey] = useState(getApiSettings() || '');
  const navigate = useNavigate();

  const handleRegister = (e) => {
    e.preventDefault();
    if (!name || !email || !password) {
      toast.error('Please fill in all fields');
      return;
    }
    
    // Mock registration
    saveUser({ name, email, role: 'student' });
    if (apiKey) saveApiSettings(apiKey);
    
    toast.success('Account created successfully!');
    navigate('/dashboard');
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6 relative overflow-hidden">
      <div className="absolute top-1/4 right-1/4 w-96 h-96 bg-primary/20 rounded-full mix-blend-screen filter blur-[100px] opacity-50 animate-float pointer-events-none"></div>
      <div className="absolute bottom-1/4 left-1/4 w-96 h-96 bg-secondary/20 rounded-full mix-blend-screen filter blur-[100px] opacity-50 animate-float pointer-events-none" style={{ animationDelay: '1.5s' }}></div>

      <GlassCard className="w-full max-w-md z-10 p-8">
        <div className="flex flex-col items-center mb-8">
          <div className="w-16 h-16 bg-gradient-to-br from-primary to-secondary rounded-2xl flex items-center justify-center shadow-lg shadow-primary/20 mb-4">
            <FiShield size={32} className="text-white" />
          </div>
          <h2 className="text-3xl font-bold text-center text-white">Create Account</h2>
          <p className="text-gray-400 mt-2 text-center">Join PrivacyShield AI</p>
        </div>

        <form onSubmit={handleRegister} className="space-y-5">
          <Input 
            label="Full Name" 
            type="text" 
            placeholder="John Doe" 
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
          <Input 
            label="Email Address" 
            type="email" 
            placeholder="you@example.com" 
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <Input 
            label="Password" 
            type="password" 
            placeholder="••••••••" 
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          
          <div className="pt-4 border-t border-slate-700/50 mt-4">
             <div className="flex items-center gap-2 mb-2">
              <FiKey className="text-primary" />
              <label className="text-sm font-medium text-gray-300">Gemini API Key (Optional)</label>
            </div>
            <Input 
              type="password" 
              placeholder="AIzaSy..." 
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              className="text-sm"
            />
          </div>

          <Button type="submit" className="w-full mt-6 py-3">
            Register
          </Button>
        </form>

        <p className="text-center text-sm text-gray-400 mt-6">
          Already have an account? <Link to="/login" className="text-primary hover:text-primary/80 transition-colors">Sign in</Link>
        </p>
      </GlassCard>
    </div>
  );
};

export default Register;
