import React, { useState, useEffect, useRef } from 'react';
import { chatWithGemini } from '../utils/gemini';
import { getChatHistory, saveChatHistory } from '../utils/storage';
import { FiSend, FiCpu, FiUser, FiTrash2 } from 'react-icons/fi';
import GlassCard from '../components/UI/GlassCard';
import Button from '../components/UI/Button';
import { toast } from 'react-hot-toast';
import { motion } from 'framer-motion';

const Assistant = () => {
  const [input, setInput] = useState('');
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    const saved = getChatHistory();
    if (saved.length > 0) {
      setHistory(saved);
    } else {
      setHistory([{ role: 'model', text: 'Hello! I am your AI Privacy Assistant. Ask me anything about GDPR, Federated Learning, Data Security, or Ethical AI.' }]);
    }
  }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    if (history.length > 1) {
      saveChatHistory(history);
    }
  }, [history]);

  const handleSend = async (e) => {
    e.preventDefault();
    if (!input.trim() || loading) return;

    const userMsg = input.trim();
    setInput('');
    const newHistory = [...history, { role: 'user', text: userMsg }];
    setHistory(newHistory);
    setLoading(true);

    try {
      const response = await chatWithGemini(userMsg, newHistory.slice(0, -1)); // Send context
      setHistory([...newHistory, { role: 'model', text: response }]);
    } catch (error) {
      toast.error('Failed to get AI response. Check your API key.');
      setHistory([...newHistory, { role: 'model', text: 'Sorry, I encountered an error. Please check your Gemini API key in Settings.' }]);
    } finally {
      setLoading(false);
    }
  };

  const clearHistory = () => {
    const initial = [{ role: 'model', text: 'Chat history cleared. How can I help you today?' }];
    setHistory(initial);
    saveChatHistory(initial);
    toast.success('Chat cleared');
  };

  return (
    <div className="flex flex-col h-[calc(100vh-8rem)]">
      <div className="flex justify-between items-center mb-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">AI Privacy Assistant</h1>
          <p className="text-sm text-gray-500 dark:text-gray-400">Powered by Gemini 1.5 Flash</p>
        </div>
        <Button variant="ghost" onClick={clearHistory} className="text-red-400 hover:text-red-300">
          <FiTrash2 size={18} /> <span className="hidden sm:inline">Clear Chat</span>
        </Button>
      </div>

      <GlassCard className="flex-1 flex flex-col overflow-hidden p-0">
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {history.map((msg, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex gap-4 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}
            >
              <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 shadow-lg ${msg.role === 'user' ? 'bg-gradient-to-br from-primary to-accent' : 'bg-gradient-to-br from-secondary to-purple-600'
                }`}>
                {msg.role === 'user' ? <FiUser className="text-white" /> : <FiCpu className="text-white" />}
              </div>
              <div className={`max-w-[75%] p-4 rounded-2xl ${msg.role === 'user'
                ? 'bg-primary/10 border border-primary/20 text-gray-800 dark:text-gray-200 rounded-tr-none'
                : 'bg-slate-800/50 border border-slate-700 text-gray-800 dark:text-gray-200 rounded-tl-none'
                }`}>
                <p className="whitespace-pre-wrap text-sm leading-relaxed">{msg.text}</p>
              </div>
            </motion.div>
          ))}
          {loading && (
            <div className="flex gap-4">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-secondary to-purple-600 flex items-center justify-center flex-shrink-0 shadow-lg animate-pulse">
                <FiCpu className="text-white" />
              </div>
              <div className="p-4 rounded-2xl bg-slate-800/50 border border-slate-700 rounded-tl-none flex items-center gap-2">
                <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></span>
                <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></span>
                <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></span>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        <div className="p-4 bg-white/5 dark:bg-slate-900/50 border-t border-gray-200 dark:border-slate-700/50 backdrop-blur-md">
          <form onSubmit={handleSend} className="flex gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about data privacy, AI ethics, GDPR..."
              className="flex-1 bg-white dark:bg-slate-800 border border-gray-300 dark:border-slate-600 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-primary text-gray-900 dark:text-white"
            />
            <Button type="submit" disabled={!input.trim() || loading} className="px-6 rounded-xl">
              <FiSend />
            </Button>
          </form>
        </div>
      </GlassCard>
    </div>
  );
};

export default Assistant;
