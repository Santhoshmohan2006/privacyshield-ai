import React, { useState } from 'react';
import GlassCard from '../components/UI/GlassCard';
import Button from '../components/UI/Button';
import Input from '../components/UI/Input';
import { analyzePrivacyRisk } from '../utils/nlp';
import { analyzeRiskExplanation } from '../utils/gemini';
import { FiShield, FiAlertTriangle, FiCheckCircle } from 'react-icons/fi';
import { toast } from 'react-hot-toast';

const Analyzer = () => {
  const [text, setText] = useState('');
  const [result, setResult] = useState(null);
  const [explanation, setExplanation] = useState('');
  const [loading, setLoading] = useState(false);

  const handleAnalyze = async () => {
    if (!text.trim()) {
      toast.error('Please enter some text to analyze');
      return;
    }

    setLoading(true);
    try {
      // 1. Local JS Analysis
      const localAnalysis = analyzePrivacyRisk(text);
      setResult(localAnalysis);

      // 2. Gemini Explanation based on Local Score
      const aiExplain = await analyzeRiskExplanation(text, localAnalysis.score);
      setExplanation(aiExplain);
    } catch (error) {
      toast.error('Error during analysis');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Privacy Risk Analyzer</h1>
        <p className="text-gray-500 dark:text-gray-400">Identify PII and privacy risks in text using local NLP and AI</p>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <GlassCard className="flex flex-col">
          <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Input Text</h2>
          <Input
            as="textarea"
            rows={10}
            placeholder="Paste text, email, or a document snippet here to check for Personally Identifiable Information (PII) or privacy risks..."
            value={text}
            onChange={(e) => setText(e.target.value)}
            className="flex-1 font-mono text-sm resize-none"
          />
          <Button 
            onClick={handleAnalyze} 
            disabled={loading || !text.trim()} 
            className="w-full mt-4 py-3"
          >
            {loading ? 'Analyzing text...' : 'Analyze Risk'}
          </Button>
        </GlassCard>

        {result ? (
          <div className="space-y-6">
            <GlassCard className="text-center">
              <h2 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">Privacy Risk Score</h2>
              <div className="flex justify-center items-center gap-4 my-4">
                <div className={`w-24 h-24 rounded-full flex items-center justify-center border-4 ${
                  result.level === 'Low' ? 'border-green-500 text-green-500' :
                  result.level === 'Medium' ? 'border-yellow-500 text-yellow-500' :
                  'border-red-500 text-red-500'
                }`}>
                  <span className="text-3xl font-bold">{Math.round(result.score)}</span>
                  <span className="text-sm self-end mb-5">/10</span>
                </div>
              </div>
              <p className={`font-bold ${
                  result.level === 'Low' ? 'text-green-500' :
                  result.level === 'Medium' ? 'text-yellow-500' :
                  'text-red-500'
                }`}>
                {result.level} Risk
              </p>
            </GlassCard>

            {result.matches.length > 0 && (
              <GlassCard>
                <h3 className="font-semibold text-gray-900 dark:text-white mb-3 flex items-center gap-2">
                  <FiAlertTriangle className="text-yellow-500" /> Detected Risks (TF-IDF)
                </h3>
                <div className="flex flex-wrap gap-2">
                  {result.matches.map((m, i) => (
                    <span key={i} className="px-3 py-1 bg-red-500/10 text-red-500 border border-red-500/20 rounded-full text-xs font-medium">
                      {m.keyword} ({m.count})
                    </span>
                  ))}
                </div>
              </GlassCard>
            )}

            <GlassCard>
              <h3 className="font-semibold text-gray-900 dark:text-white mb-3 flex items-center gap-2">
                <span className="text-xl">✨</span> AI Explanation
              </h3>
              {loading ? (
                <div className="animate-pulse space-y-2">
                  <div className="h-4 bg-gray-200 dark:bg-slate-700 rounded w-3/4"></div>
                  <div className="h-4 bg-gray-200 dark:bg-slate-700 rounded w-full"></div>
                  <div className="h-4 bg-gray-200 dark:bg-slate-700 rounded w-5/6"></div>
                </div>
              ) : (
                <p className="text-sm text-gray-700 dark:text-gray-300 leading-relaxed">
                  {explanation}
                </p>
              )}
            </GlassCard>
          </div>
        ) : (
          <GlassCard className="flex flex-col items-center justify-center text-center text-gray-500 min-h-[400px]">
            <FiShield size={48} className="mb-4 opacity-50" />
            <p>Enter text and click Analyze to see privacy risk score, keyword detection, and AI explanation.</p>
          </GlassCard>
        )}
      </div>
    </div>
  );
};

export default Analyzer;
