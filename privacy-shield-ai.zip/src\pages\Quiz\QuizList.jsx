import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import GlassCard from '../../components/UI/GlassCard';
import Button from '../../components/UI/Button';
import Badge from '../../components/UI/Badge';
import { FiClock, FiCheckCircle } from 'react-icons/fi';
import quizzesData from '../../data/quizzes.json';

const QuizList = () => {
  const navigate = useNavigate();

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Privacy Quizzes</h1>
        <p className="text-gray-500 dark:text-gray-400">Test your knowledge on data privacy and AI ethics</p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {quizzesData.map((quiz, idx) => (
          <GlassCard key={quiz.id} delay={idx * 0.1} className="flex flex-col h-full">
            <div className="flex justify-between items-start mb-4">
              <Badge 
                text={quiz.difficulty} 
                color={quiz.difficulty === 'Beginner' ? 'success' : quiz.difficulty === 'Intermediate' ? 'warning' : 'danger'} 
              />
              <span className="flex items-center text-xs text-gray-400 gap-1"><FiClock /> 5 mins</span>
            </div>
            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">{quiz.title}</h3>
            <p className="text-sm text-gray-500 dark:text-gray-400 flex-1 mb-6">
              {quiz.questions.length} questions
            </p>
            <Button onClick={() => navigate(`/quiz/${quiz.id}`)} className="w-full">
              Start Quiz
            </Button>
          </GlassCard>
        ))}
      </div>
    </div>
  );
};

export default QuizList;
