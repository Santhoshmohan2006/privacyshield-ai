import React, { useState } from 'react';
import GlassCard from '../components/UI/GlassCard';
import Button from '../components/UI/Button';
import Input from '../components/UI/Input';
import { analyzeCompliance } from '../utils/gemini';
import { FiFileText, FiDownload } from 'react-icons/fi';
import { toast } from 'react-hot-toast';
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';

const Compliance = () => {
  const [policy, setPolicy] = useState('');
  const [report, setReport] = useState('');
  const [loading, setLoading] = useState(false);

  const handleCheck = async () => {
    if (!policy.trim()) {
      toast.error('Please paste a privacy policy');
      return;
    }

    setLoading(true);
    try {
      const res = await analyzeCompliance(policy);
      setReport(res);
      toast.success('Analysis complete!');
    } catch (error) {
      toast.error('Failed to analyze policy. Check your API key.');
    } finally {
      setLoading(false);
    }
  };

  const downloadPDF = async () => {
    const reportElement = document.getElementById('compliance-report');
    if (!reportElement) return;

    try {
      toast.loading('Generating PDF...', { id: 'pdf' });
      const canvas = await html2canvas(reportElement, { scale: 2 });
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
      
      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
      pdf.save('compliance-report.pdf');
      toast.success('PDF Downloaded!', { id: 'pdf' });
    } catch (error) {
      toast.error('Failed to generate PDF', { id: 'pdf' });
    }
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">GDPR & CCPA Compliance Checker</h1>
        <p className="text-gray-500 dark:text-gray-400">Analyze privacy policies to identify missing legal requirements.</p>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <GlassCard className="flex flex-col">
          <h2 className="text-lg font-bold text-gray-900 dark:text-white mb-4">Paste Privacy Policy</h2>
          <Input
            as="textarea"
            rows={15}
            placeholder="Paste the contents of a privacy policy here..."
            value={policy}
            onChange={(e) => setPolicy(e.target.value)}
            className="flex-1 text-sm resize-none"
          />
          <Button 
            onClick={handleCheck} 
            disabled={loading || !policy.trim()} 
            className="w-full mt-4"
          >
            {loading ? 'Analyzing...' : 'Generate Compliance Report'}
          </Button>
        </GlassCard>

        <GlassCard className="flex flex-col relative overflow-hidden">
          <div className="flex justify-between items-center mb-4 z-10 relative">
            <h2 className="text-lg font-bold text-gray-900 dark:text-white flex items-center gap-2">
              <FiFileText className="text-primary" /> AI Analysis Report
            </h2>
            {report && (
              <Button variant="outline" onClick={downloadPDF} className="py-1 px-3 text-sm">
                <FiDownload /> Export PDF
              </Button>
            )}
          </div>

          <div 
            id="compliance-report" 
            className="flex-1 overflow-y-auto bg-white dark:bg-slate-800 p-6 rounded-xl border border-gray-200 dark:border-slate-700"
          >
            {report ? (
              <div className="prose prose-sm dark:prose-invert max-w-none whitespace-pre-wrap font-sans text-gray-800 dark:text-gray-200">
                {report}
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-gray-400">
                <FiFileText size={48} className="mb-4 opacity-50" />
                <p>Run analysis to see missing areas and recommendations.</p>
              </div>
            )}
          </div>
        </GlassCard>
      </div>
    </div>
  );
};

export default Compliance;
