import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { FiShield, FiCpu, FiBookOpen, FiArrowRight } from 'react-icons/fi';
import Button from '../components/UI/Button';
import GlassCard from '../components/UI/GlassCard';

const Landing = () => {
  const navigate = useNavigate();

  const features = [
    { icon: <FiCpu size={24} />, title: 'AI Assistant', desc: 'Chat directly with Gemini about privacy.' },
    { icon: <FiBookOpen size={24} />, title: 'Interactive Learning', desc: 'Quizzes on GDPR, PII, and Security.' },
    { icon: <FiShield size={24} />, title: 'Risk Analyzer', desc: 'NLP based document privacy scoring.' },
  ];

  return (
    <div className="min-h-screen bg-darkBg text-white relative overflow-hidden font-sans">
      {/* Dynamic Background */}
      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] opacity-20 pointer-events-none"></div>
      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-primary/30 rounded-full blur-[150px] animate-float"></div>
      <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-secondary/30 rounded-full blur-[150px] animate-float" style={{ animationDelay: '2s' }}></div>

      {/* Navbar */}
      <nav className="relative z-10 flex justify-between items-center p-6 lg:px-20">
        <div className="flex items-center gap-2">
          <FiShield className="text-primary text-3xl" />
          <h1 className="text-2xl font-bold text-gradient">PrivacyShield</h1>
        </div>
        <div className="flex gap-4">
          <Button variant="ghost" onClick={() => navigate('/login')}>Login</Button>
          <Button onClick={() => navigate('/register')}>Get Started</Button>
        </div>
      </nav>

      {/* Hero Section */}
      <main className="relative z-10 flex flex-col items-center justify-center text-center px-6 mt-20 lg:mt-32">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl"
        >

          <h2 className="text-5xl lg:text-7xl font-extrabold leading-tight mb-6 tracking-tight">
            Master Data Privacy with <br className="hidden md:block"/>
            <span className="text-gradient">Intelligent AI</span>
          </h2>
          <p className="text-lg text-gray-400 mb-10 max-w-2xl mx-auto leading-relaxed">
            An advanced, fully frontend learning platform to understand data privacy, GDPR, ethical AI, and surveillance risks through interactive AI and local NLP models.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button onClick={() => navigate('/register')} className="py-4 px-8 text-lg rounded-full group">
              Start Learning Now
              <FiArrowRight className="group-hover:translate-x-1 transition-transform" />
            </Button>
          </div>
        </motion.div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-3 gap-6 w-full max-w-5xl mt-24 pb-20">
          {features.map((feature, idx) => (
            <GlassCard key={idx} delay={0.2 * idx} className="text-center p-8 flex flex-col items-center">
              <div className="w-14 h-14 bg-gradient-to-br from-primary/20 to-secondary/20 rounded-2xl flex items-center justify-center text-primary mb-6 shadow-inner border border-primary/10">
                {feature.icon}
              </div>
              <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
              <p className="text-gray-400">{feature.desc}</p>
            </GlassCard>
          ))}
        </div>
      </main>
    </div>
  );
};

export default Landing;
