import React, { useEffect, useState } from 'react';
import { getScores, getBadges } from '../utils/storage';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import GlassCard from '../components/UI/GlassCard';
import quizzesData from '../data/quizzes.json';

const Analytics = () => {
  const [scores, setScores] = useState([]);
  
  useEffect(() => {
    setScores(getScores());
  }, []);

  const getQuizName = (id) => {
    const q = quizzesData.find(quiz => quiz.id === id);
    return q ? q.title : `Quiz ${id}`;
  };

  const barData = scores.slice(-5).map(s => ({
    name: getQuizName(s.quizId).substring(0, 10) + '...',
    score: Math.round((s.score / s.maxScore) * 100)
  }));

  const pieData = [
    { name: 'Completed', value: scores.length },
    { name: 'Pending', value: quizzesData.length - scores.length > 0 ? quizzesData.length - scores.length : 0 },
  ];
  const COLORS = ['#38bdf8', '#334155'];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Performance Analytics</h1>
        <p className="text-gray-500 dark:text-gray-400">Detailed breakdown of your learning journey</p>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <GlassCard className="h-96">
          <h2 className="text-lg font-bold text-gray-900 dark:text-white mb-6">Recent Quiz Scores (%)</h2>
          {scores.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={barData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                <XAxis dataKey="name" stroke="#94a3b8" fontSize={12} />
                <YAxis stroke="#94a3b8" />
                <Tooltip cursor={{fill: '#334155', opacity: 0.2}} contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px', color: '#fff' }} />
                <Bar dataKey="score" fill="#38bdf8" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-full flex items-center justify-center text-gray-500">No data available</div>
          )}
        </GlassCard>

        <GlassCard className="h-96">
          <h2 className="text-lg font-bold text-gray-900 dark:text-white mb-6">Course Completion</h2>
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={pieData}
                cx="50%"
                cy="50%"
                innerRadius={80}
                outerRadius={110}
                paddingAngle={5}
                dataKey="value"
                stroke="none"
              >
                {pieData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px', color: '#fff' }} />
            </PieChart>
          </ResponsiveContainer>
          <div className="flex justify-center gap-6 mt-[-40px]">
            <div className="flex items-center gap-2"><div className="w-3 h-3 bg-primary rounded-full"></div><span className="text-sm text-gray-400">Completed</span></div>
            <div className="flex items-center gap-2"><div className="w-3 h-3 bg-slate-600 rounded-full"></div><span className="text-sm text-gray-400">Pending</span></div>
          </div>
        </GlassCard>
      </div>
    </div>
  );
};

export default Analytics;
