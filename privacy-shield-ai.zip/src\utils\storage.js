// LocalStorage wrapper

export const saveUser = (user) => {
  localStorage.setItem('user', JSON.stringify(user));
};

export const getUser = () => {
  const user = localStorage.getItem('user');
  return user ? JSON.parse(user) : null;
};

export const logoutUser = () => {
  localStorage.removeItem('user');
};

export const saveScore = (quizId, score, maxScore) => {
  const scores = JSON.parse(localStorage.getItem('scores') || '[]');
  scores.push({ quizId, score, maxScore, date: new Date().toISOString() });
  localStorage.setItem('scores', JSON.stringify(scores));
  updateBadges(score, maxScore);
};

export const getScores = () => {
  return JSON.parse(localStorage.getItem('scores') || '[]');
};

export const updateBadges = (score, maxScore) => {
  if (score === maxScore) {
    const badges = JSON.parse(localStorage.getItem('badges') || '[]');
    if (!badges.includes('Perfect Score')) {
      badges.push('Perfect Score');
      localStorage.setItem('badges', JSON.stringify(badges));
    }
  }
};

export const getBadges = () => {
  return JSON.parse(localStorage.getItem('badges') || '[]');
};

export const getChatHistory = () => {
  return JSON.parse(localStorage.getItem('chatHistory') || '[]');
};

export const saveChatHistory = (history) => {
  localStorage.setItem('chatHistory', JSON.stringify(history));
};

export const saveApiSettings = (key) => {
  localStorage.setItem('geminiApiKey', key);
};

export const getApiSettings = () => {
  return localStorage.getItem('geminiApiKey');
};
