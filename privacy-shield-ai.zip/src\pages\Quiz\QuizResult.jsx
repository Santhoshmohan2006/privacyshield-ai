import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import GlassCard from '../../components/UI/GlassCard';
import Button from '../../components/UI/Button';
import { FiAward, FiArrowLeft, FiCheck, FiX } from 'react-icons/fi';
import { chatWithGemini } from '../../utils/gemini';
import quizzesData from '../../data/quizzes.json';
import { motion } from 'framer-motion';

const QuizResult = () => {
  const { state } = useLocation();
  const { id } = useParams();
  const navigate = useNavigate();
  const [feedback, setFeedback] = useState('Generating personalized AI feedback...');

  const quiz = quizzesData.find(q => q.id === id);

  useEffect(() => {
    if (!state || !quiz) {
      navigate('/quiz');
      return;
    }

    const generateFeedback = async () => {
      try {
        const prompt = `I just took a quiz on ${quiz.title}. I scored ${state.score} out of ${state.total}. Provide a brief, encouraging feedback (2 sentences) and one tip for improvement related to this topic.`;
        const res = await chatWithGemini(prompt);
        setFeedback(res);
      } catch (error) {
        setFeedback("Great job completing the quiz! Keep learning to improve your score.");
      }
    };
    generateFeedback();
  }, [state, quiz, navigate]);

  if (!state || !quiz) return null;

  const percentage = (state.score / state.total) * 100;
  let color = 'text-red-500';
  if (percentage >= 70) color = 'text-yellow-500';
  if (percentage >= 90) color = 'text-green-500';

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <Button variant="ghost" onClick={() => navigate('/quiz')} className="mb-4">
        <FiArrowLeft /> Back to Quizzes
      </Button>

      <GlassCard className="text-center p-10">
        <motion.div 
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: 'spring', stiffness: 200, damping: 15 }}
          className="w-24 h-24 mx-auto bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center mb-6 shadow-xl shadow-primary/20"
        >
          <FiAward size={48} className="text-white" />
        </motion.div>
        
        <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">Quiz Completed!</h2>
        <p className="text-gray-500 dark:text-gray-400 mb-8">{quiz.title}</p>
        
        <div className="flex justify-center items-center gap-8 mb-8">
          <div>
            <p className="text-sm text-gray-500">Your Score</p>
            <p className={`text-5xl font-extrabold ${color}`}>{state.score}<span className="text-2xl text-gray-400">/{state.total}</span></p>
          </div>
        </div>

        <div className="p-6 bg-primary/10 border border-primary/20 rounded-2xl text-left">
          <h3 className="font-semibold text-primary mb-2 flex items-center gap-2">
            <span className="text-xl">✨</span> AI Feedback
          </h3>
          <p className="text-gray-700 dark:text-gray-300 text-sm leading-relaxed">{feedback}</p>
        </div>
      </GlassCard>

      <GlassCard>
        <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-6">Review Answers</h3>
        <div className="space-y-4">
          {quiz.questions.map((q, i) => {
            const isCorrect = state.answers[i] === q.answer;
            return (
              <div key={i} className="p-4 border border-gray-200 dark:border-slate-700 rounded-xl bg-white/5 dark:bg-slate-800/30">
                <p className="font-medium text-gray-900 dark:text-white mb-3">{i+1}. {q.q}</p>
                <div className="space-y-2">
                  {q.options.map((opt, optIdx) => {
                    let optClass = "text-gray-500 dark:text-gray-400";
                    let Icon = null;
                    
                    if (optIdx === q.answer) {
                      optClass = "text-green-500 font-semibold";
                      Icon = <FiCheck className="inline mr-2" />;
                    } else if (optIdx === state.answers[i] && !isCorrect) {
                      optClass = "text-red-500";
                      Icon = <FiX className="inline mr-2" />;
                    }

                    return (
                      <p key={optIdx} className={`text-sm flex items-center ${optClass}`}>
                        {Icon || <span className="w-4 mr-2 inline-block"></span>}
                        {opt}
                      </p>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </GlassCard>
    </div>
  );
};

export default QuizResult;
