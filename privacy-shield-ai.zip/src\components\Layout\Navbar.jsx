import React from 'react';
import { FiSun, FiMoon, FiLogOut, FiMenu } from 'react-icons/fi';
import { getUser, logoutUser } from '../../utils/storage';
import { useNavigate } from 'react-router-dom';

const Navbar = ({ theme, toggleTheme, toggleSidebar }) => {
  const navigate = useNavigate();
  const user = getUser();

  const handleLogout = () => {
    logoutUser();
    navigate('/login');
  };

  return (
    <header className="h-20 glass-dark border-b border-slate-700/50 flex items-center justify-between px-6 sticky top-0 z-10 backdrop-blur-xl">
      <div className="flex items-center gap-4">
        <button onClick={toggleSidebar} className="md:hidden text-gray-300 hover:text-white">
          <FiMenu size={24} />
        </button>
        <h2 className="text-xl font-semibold text-white hidden sm:block">
          Welcome back, <span className="text-primary">{user?.name || 'User'}</span>
        </h2>
      </div>

      <div className="flex items-center gap-4">
        <button 
          onClick={toggleTheme}
          className="p-2 rounded-full hover:bg-slate-800 text-gray-300 transition-colors"
        >
          {theme === 'dark' ? <FiSun size={20} /> : <FiMoon size={20} />}
        </button>
        
        <div className="flex items-center gap-3 pl-4 border-l border-slate-700/50">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white font-bold shadow-lg shadow-primary/20">
            {user?.name?.charAt(0).toUpperCase() || 'U'}
          </div>
          <button 
            onClick={handleLogout}
            className="text-gray-400 hover:text-red-400 transition-colors"
            title="Logout"
          >
            <FiLogOut size={20} />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Navbar;
