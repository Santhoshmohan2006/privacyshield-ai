import React, { useState, useEffect } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { FiTrendingUp, FiAward, FiShield, FiActivity } from 'react-icons/fi';
import GlassCard from '../components/UI/GlassCard';
import Badge from '../components/UI/Badge';
import { getScores, getBadges, getUser } from '../utils/storage';

const Dashboard = () => {
  const user = getUser();
  const [scores, setScores] = useState([]);
  const [badges, setBadges] = useState([]);

  useEffect(() => {
    setScores(getScores());
    setBadges(getBadges());
  }, []);

  // Mock data for the chart since localStorage might be empty initially
  const chartData = scores.length > 0 ? scores.map((s, i) => ({
    name: `Quiz ${i+1}`,
    score: (s.score / s.maxScore) * 100
  })) : [
    { name: 'Mon', score: 40 },
    { name: 'Tue', score: 60 },
    { name: 'Wed', score: 55 },
    { name: 'Thu', score: 80 },
    { name: 'Fri', score: 100 },
  ];

  const averageScore = scores.length > 0 
    ? Math.round(scores.reduce((acc, curr) => acc + (curr.score/curr.maxScore)*100, 0) / scores.length) 
    : 0;

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Dashboard Overview</h1>
          <p className="text-gray-500 dark:text-gray-400">Track your privacy learning progress</p>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <GlassCard className="flex items-center gap-4">
          <div className="p-4 bg-primary/20 rounded-xl text-primary">
            <FiShield size={24} />
          </div>
          <div>
            <p className="text-sm text-gray-500 dark:text-gray-400">Privacy Score</p>
            <p className="text-2xl font-bold text-gray-900 dark:text-white">{averageScore > 0 ? averageScore : 85}/100</p>
          </div>
        </GlassCard>
        
        <GlassCard className="flex items-center gap-4" delay={0.1}>
          <div className="p-4 bg-secondary/20 rounded-xl text-secondary">
            <FiActivity size={24} />
          </div>
          <div>
            <p className="text-sm text-gray-500 dark:text-gray-400">Quizzes Taken</p>
            <p className="text-2xl font-bold text-gray-900 dark:text-white">{scores.length}</p>
          </div>
        </GlassCard>

        <GlassCard className="flex items-center gap-4" delay={0.2}>
          <div className="p-4 bg-green-500/20 rounded-xl text-green-500">
            <FiAward size={24} />
          </div>
          <div>
            <p className="text-sm text-gray-500 dark:text-gray-400">Badges Earned</p>
            <p className="text-2xl font-bold text-gray-900 dark:text-white">{badges.length}</p>
          </div>
        </GlassCard>

        <GlassCard className="flex items-center gap-4" delay={0.3}>
          <div className="p-4 bg-yellow-500/20 rounded-xl text-yellow-500">
            <FiTrendingUp size={24} />
          </div>
          <div>
            <p className="text-sm text-gray-500 dark:text-gray-400">Current Streak</p>
            <p className="text-2xl font-bold text-gray-900 dark:text-white">3 Days</p>
          </div>
        </GlassCard>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chart */}
        <GlassCard className="lg:col-span-2 h-96 flex flex-col" delay={0.4}>
          <h2 className="text-lg font-bold text-gray-900 dark:text-white mb-4">Learning Progress</h2>
          <div className="flex-1 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorScore" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#38bdf8" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#38bdf8" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" opacity={0.5} />
                <XAxis dataKey="name" stroke="#94a3b8" />
                <YAxis stroke="#94a3b8" />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px', color: '#fff' }}
                  itemStyle={{ color: '#38bdf8' }}
                />
                <Area type="monotone" dataKey="score" stroke="#38bdf8" fillOpacity={1} fill="url(#colorScore)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </GlassCard>

        {/* AI Recommendations */}
        <GlassCard className="h-96 flex flex-col" delay={0.5}>
          <h2 className="text-lg font-bold text-gray-900 dark:text-white mb-4">AI Recommendations</h2>
          <div className="flex-1 overflow-y-auto space-y-4 pr-2">
            <div className="p-4 rounded-xl bg-gradient-to-r from-primary/10 to-transparent border-l-2 border-primary">
              <h3 className="font-semibold text-gray-900 dark:text-white text-sm">Review GDPR Basics</h3>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">Your last quiz showed some gaps in GDPR knowledge.</p>
            </div>
            <div className="p-4 rounded-xl bg-gradient-to-r from-secondary/10 to-transparent border-l-2 border-secondary">
              <h3 className="font-semibold text-gray-900 dark:text-white text-sm">Try Risk Analyzer</h3>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">Analyze a sample privacy policy to understand local NLP.</p>
            </div>
            <div className="p-4 rounded-xl bg-gradient-to-r from-green-500/10 to-transparent border-l-2 border-green-500">
              <h3 className="font-semibold text-gray-900 dark:text-white text-sm">Chat with Gemini</h3>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">Ask the AI Assistant about Federated Learning.</p>
            </div>
          </div>
        </GlassCard>
      </div>
    </div>
  );
};

export default Dashboard;
