import React, { useState, useEffect } from 'react';
import GlassCard from '../components/UI/GlassCard';
import Button from '../components/UI/Button';
import Input from '../components/UI/Input';
import { getUser, getApiSettings, saveApiSettings, getBadges } from '../utils/storage';
import { FiUser, FiSettings, FiAward } from 'react-icons/fi';
import { toast } from 'react-hot-toast';

const Profile = () => {
  const [user, setUser] = useState(null);
  const [apiKey, setApiKey] = useState('');
  const [badges, setBadges] = useState([]);

  useEffect(() => {
    setUser(getUser());
    setApiKey(getApiSettings() || '');
    setBadges(getBadges());
  }, []);

  const handleSaveSettings = () => {
    saveApiSettings(apiKey);
    toast.success('Settings saved successfully!');
    // Trigger reload to update Gemini client instance if needed
    setTimeout(() => window.location.reload(), 1000);
  };

  if (!user) return null;

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Profile & Settings</h1>

      <div className="grid md:grid-cols-3 gap-6">
        <GlassCard className="md:col-span-1 flex flex-col items-center text-center p-8">
          <div className="w-32 h-32 rounded-full bg-gradient-to-br from-primary to-secondary flex items-center justify-center shadow-xl shadow-primary/20 mb-6 border-4 border-white/10">
            <FiUser size={64} className="text-white" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">{user.name}</h2>
          <p className="text-gray-500 dark:text-gray-400">{user.email}</p>
          <span className="mt-4 px-4 py-1 bg-primary/10 text-primary border border-primary/20 rounded-full text-sm font-semibold capitalize">
            {user.role}
          </span>
        </GlassCard>

        <div className="md:col-span-2 space-y-6">
          <GlassCard>
            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-6 flex items-center gap-2">
              <FiSettings className="text-primary" /> App Settings
            </h3>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 block">
                  Google Gemini API Key
                </label>
                <div className="flex gap-2">
                  <Input 
                    type="password" 
                    placeholder="Enter your Gemini 1.5 Flash API Key" 
                    value={apiKey}
                    onChange={(e) => setApiKey(e.target.value)}
                    className="flex-1"
                  />
                  <Button onClick={handleSaveSettings}>Save</Button>
                </div>
                <p className="text-xs text-gray-500 mt-2">
                  Your API key is stored locally in your browser and is never sent to our servers.
                </p>
              </div>
            </div>
          </GlassCard>

          <GlassCard>
            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-6 flex items-center gap-2">
              <FiAward className="text-yellow-500" /> Gamification Badges
            </h3>
            <div className="flex flex-wrap gap-4">
              {badges.length > 0 ? badges.map((badge, idx) => (
                <div key={idx} className="flex flex-col items-center p-4 bg-white/5 dark:bg-slate-800/50 rounded-2xl border border-yellow-500/30 w-32">
                  <div className="w-12 h-12 bg-yellow-500/20 text-yellow-500 rounded-full flex items-center justify-center mb-2">
                    <FiAward size={24} />
                  </div>
                  <span className="text-xs font-semibold text-center text-gray-300">{badge}</span>
                </div>
              )) : (
                <p className="text-sm text-gray-500">No badges earned yet. Complete quizzes perfectly to earn badges!</p>
              )}
            </div>
          </GlassCard>
        </div>
      </div>
    </div>
  );
};

export default Profile;
